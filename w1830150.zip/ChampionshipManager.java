//Name:- M.A.Oshadha Imantha
//UoW No:-W1830150
//IIT No:-20200488
//”I confirm that I understand what plagiarism is and have read and understood the section on Assessment Offences in the Essential Information for Students. The work that I have submitted is entirely my own. Any work from other authors is duly  referenced and acknowledged.”




public interface ChampionshipManager {
    public int getf1drivers();
    public int getf1cars();
    public void NewDriver();
    public void deleteDriver();
    public void changeDriver();
    public void displayStats();
    public void displayTable();
    public void addRace();
    public void saveInfo();
    public void recoverInfo();
}