// Driver.java
//Name:- M.A.Oshadha Imantha
//UoW No:-W1830150
//IIT No:-20200488
//”I confirm that I understand what plagiarism is and have read and understood the section on Assessment Offences in the Essential Information for Students. The work that I have submitted is entirely my own. Any work from other authors is duly  referenced and acknowledged.”



public abstract class Driver {
    private String name;
    private String location;
    private String team;

    public Driver(String name, String location, String team){
        this.name = name;
        this.location = location;
        this.team = team;
    }

    public Driver() {

    }

    public String getName(){
        return name;
    }

    public String getLocation(){
        return location;
    }

    public String getTeam(){
        return team;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public void setTeam(String team) {
        this.team = team;
    }

}
