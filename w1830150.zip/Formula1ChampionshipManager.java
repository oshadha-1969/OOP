// Formula1ChampionshipManager.java
//Name:- M.A.Oshadha Imantha
//UoW No:-W1830150
//IIT No:-20200488
//”I confirm that I understand what plagiarism is and have read and understood the section on Assessment Offences in the Essential Information for Students. The work that I have submitted is entirely my own. Any work from other authors is duly  referenced and acknowledged.”


import java.io.*;
import java.nio.charset.StandardCharsets;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;


public class Formula1ChampionshipManager extends Formula1Driver implements ChampionshipManager{
    private int f1drivers;
    private final int f1cars;
    private String man;
    private int fp=0;
    private int sp=0;
    private int tp=0;
    private int noOfRaces=0;
    private int currentPoints;
    Scanner input = new Scanner(System.in);

    Random random = new Random();

    static ArrayList<Formula1Driver> driverList = new ArrayList<Formula1Driver>();

    public void getDriverList() {
    }

    public Formula1ChampionshipManager(int f1drivers, int f1cars){
        super();
        this.f1drivers = f1drivers;
        this.f1cars = f1cars;
    }

    public int getF1drivers() {
        return f1drivers;
    }

    public void setF1drivers(int f1drivers) {
        this.f1drivers = f1drivers;
    }

    public int getFp() {
        return fp;
    }

    public void setFp(int fp) {
        this.fp = fp;
    }

    public int getSp() {
        return sp;
    }

    public void setSp(int sp) {
        this.sp = sp;
    }

    public int getTp() {
        return tp;
    }

    public void setTp(int tp) {
        this.tp = tp;
    }

    public int getNoOfRaces() {
        return noOfRaces;
    }

    public void setNoOfRaces(int noOfRaces) {
        this.noOfRaces = noOfRaces;
    }

    public int getf1drivers(){
        return f1drivers;
    }

    public int getf1cars(){
        return f1cars;
    }



    public void createNewDriver() {
        System.out.println("Enter the new driver's name: ");
        super.setName(input.nextLine());
        System.out.println("Enter "+super.getName()+"'s team name: ");
        super.setTeam(input.nextLine());
        System.out.println("Enter "+super.getName()+"'s country: ");
        super.setLocation(input.nextLine());
        super.setRaces(getNoOfRaces());
        super.setFirstPositions(getFp());
        super.setSecondPositions(getSp());
        super.setThirdPositions(getTp());
        Formula1Driver newDriver = new Formula1Driver(getName(), getLocation(), getTeam(),
                getFirstPositions(), getSecondPositions(), getThirdPositions(), getTotalPoints(), getRaces());
        driverList.add(newDriver);
        System.out.println(newDriver.getName()+" has been added to this season!");
        for(Formula1Driver driver : driverList){
            System.out.println(driver.toString());
        }
    }
    public void deleteDriver() {
        System.out.println("Enter the name of the driver you want to delete: ");
        String deletingDriver = input.next();
        for (Formula1Driver driver : driverList){
            if (deletingDriver.equals(driver.getName())){
                driverList.remove(driver);
            }
        }
        System.out.println(deletingDriver+" has been deleted!");
    }
    public void changeDriver () {
        System.out.println("Enter the team you wish to change the driver for: ");
        String changingTeam = input.next();
        for (Formula1Driver driver : driverList){
            if (changingTeam.equals(driver.getTeam())){
                System.out.println("Enter the name of the new driver: ");
                String newDriver = input.next();
                driver.setName(newDriver);
            }
        }
        System.out.println("The racer for "+changingTeam+" has been changed!");
    }
    public void displayStats () {
        System.out.println("Enter the name of the driver you wish to see the statistics for: ");
        String statDriver = input.next();
        for (Formula1Driver driver : driverList){
            if (statDriver.equals(driver.getName())){
                System.out.println("Races participated this season: "+driver.getRaces()+
                        "\nNumber of first positions: "+driver.getFirstPositions()+
                        "\nNumber of second positions: "+driver.getSecondPositions()+
                        "\nNumber of third positions: "+driver.getThirdPositions()+
                        "\nTotal number of points: "+driver.getTotalPoints());
            }
        }
    }
    public void displayTable () {
        System.out.println("Formula 1 Championship 2021 table");
        System.out.println("---------------------------------------------------------------------------------------------------------------------------------");
        System.out.printf("%10s %10s %10s %10s %10s %10s %10s %10s %10s %10s %10s", "DRIVER","|", "LOCATION","|", "TEAM","|", "POINTS","|", "1ST POSITIONS","|", "RACES");
        System.out.println();
        System.out.println("---------------------------------------------------------------------------------------------------------------------------------");
        for (Formula1Driver driver : driverList){
            System.out.format("%10s %10s %10s %10s %10s %10s %10s %10s %10s %10s %10s",
                    driver.getName(), "|", driver.getLocation(), "|", driver.getTeam(), "|", driver.getTotalPoints(), "|", driver.getFirstPositions(), "|", driver.getRaces()+"\n");
        }
        System.out.println();
        System.out.println("---------------------------------------------------------------------------------------------------------------------------------");
    }
    public void addRace () {//https://www.code4example.com/java/take-date-input-from-user-and-save-it-as-date-in-java/
        noOfRaces++;
        SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
        System.out.println("Enter the date of the new race: ");
        String raceDate = input.nextLine();
        try {
            Date date1 = format.parse(raceDate);
            System.out.println(date1);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        System.out.println("The new race has been added!");
        for (Formula1Driver driver : driverList) {
            int racePosition = (int) ((Math.random() * (9)) + 1);
            if (racePosition == 1) {
                driver.setPointsPerRace(25);
                fp++;
                driver.setFirstPositions(fp);
                currentPoints=driver.getTotalPoints()+driver.getPointsPerRace();
                driver.setTotalPoints(currentPoints);
                driver.setRaces(noOfRaces);
            } else if (racePosition == 2) {
                driver.setPointsPerRace(18);
                sp++;
                driver.setSecondPositions(sp);
                currentPoints=driver.getTotalPoints()+driver.getPointsPerRace();
                driver.setTotalPoints(currentPoints);
                driver.setRaces(noOfRaces);
            } else if (racePosition == 3) {
                driver.setPointsPerRace(15);
                tp++;
                driver.setThirdPositions(tp);
                currentPoints=driver.getTotalPoints()+driver.getPointsPerRace();
                driver.setTotalPoints(currentPoints);
                driver.setRaces(noOfRaces);
            } else if (racePosition == 4) {
                driver.setPointsPerRace(12);
                currentPoints=driver.getTotalPoints()+driver.getPointsPerRace();
                driver.setTotalPoints(currentPoints);
                driver.setRaces(noOfRaces);
            } else if (racePosition == 5) {
                driver.setPointsPerRace(10);
                currentPoints=driver.getTotalPoints()+driver.getPointsPerRace();
                driver.setTotalPoints(currentPoints);
                driver.setRaces(noOfRaces);
            } else if (racePosition == 6) {
                driver.setPointsPerRace(8);
                currentPoints=driver.getTotalPoints()+driver.getPointsPerRace();
                driver.setTotalPoints(currentPoints);
                driver.setRaces(noOfRaces);
            } else if (racePosition == 7) {
                driver.setPointsPerRace(6);
                currentPoints=driver.getTotalPoints()+driver.getPointsPerRace();
                driver.setTotalPoints(currentPoints);
                driver.setRaces(noOfRaces);
            } else if (racePosition == 8) {
                driver.setPointsPerRace(4);
                currentPoints=driver.getTotalPoints()+driver.getPointsPerRace();
                driver.setTotalPoints(currentPoints);
                driver.setRaces(noOfRaces);
            } else if (racePosition == 9) {
                driver.setPointsPerRace(2);
                currentPoints=driver.getTotalPoints()+driver.getPointsPerRace();
                driver.setTotalPoints(currentPoints);
                driver.setRaces(noOfRaces);
            } else if (racePosition == 10) {
                driver.setPointsPerRace(1);
                currentPoints=driver.getTotalPoints()+driver.getPointsPerRace();
                driver.setTotalPoints(currentPoints);
                driver.setRaces(noOfRaces);
            }
        }
    }

    public void saveInfo () {
        try {
            FileOutputStream fOut = new FileOutputStream(new File("driverObjects.txt"));
            ObjectOutputStream oOut = new ObjectOutputStream(fOut);

            oOut.writeObject(driverList);

            oOut.close();
            fOut.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        System.out.println("The data has been saved!");
    }
    public void recoverInfo () {
        try {
            FileInputStream fIn = new FileInputStream(new File("driverObjects.txt"));
            InputStream inputStream = new ByteArrayInputStream(driverList.get(0).getName().getBytes(StandardCharsets.UTF_8));
            ObjectInputStream oIn = new ObjectInputStream(fIn);

            driverList = (ArrayList<Formula1Driver>) oIn.readObject();

            System.out.println(driverList.toString());

            oIn.close();
            fIn.close();

        } catch (FileNotFoundException | ClassNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}