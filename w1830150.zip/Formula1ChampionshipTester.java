// Formula1Championship.java
//Name:- M.A.Oshadha Imantha
//UoW No:-W1830150
//IIT No:-20200488
//”I confirm that I understand what plagiarism is and have read and understood the section on Assessment Offences in the Essential Information for Students. The work that I have submitted is entirely my own. Any work from other authors is duly  referenced and acknowledged.”



import java.util.Scanner;

class Formula1Championship {
    public static void main(String[] args) {

        Formula1ChampionshipManager fcm1 = new Formula1ChampionshipManager(10, 10) {
        };

        System.out.println("---------Welcome to FORMULA 1 Championship 2021---------");

        Scanner input = new Scanner(System.in);
        String userInput;
        do {
            System.out.println("\n----Please use the following menu to do your changes----");
            System.out.println("'AD' - Create a new driver" + "\n'DD' - Delete a driver" + "\n'CD' - Change Driver"
                    + "\n'S' - Display Statistics" + "\n'DT' - Display Table" + "\n'R' - Add a race"
                    + "\n'SI' - Save information to a file" + "\n'RI' - Recover information from file"
                    + "\n'EX' - Exit Program");
            System.out.println("\nPlease enter an option:");
            userInput = input.next();
            userInput = userInput.toUpperCase();
            if (userInput.equals("AD")) {
                fcm1.createNewDriver();

            } else if (userInput.equals("DD")) {
                fcm1.deleteDriver();

            } else if (userInput.equals("CD")) {
                fcm1.changeDriver();

            } else if (userInput.equals("S")) {
                fcm1.displayStats();

            } else if (userInput.equals("DT")) {
                fcm1.displayTable();

            } else if (userInput.equals("R")) {
                fcm1.addRace();

            } else if (userInput.equals("SI")) {
                fcm1.saveInfo();

            } else if (userInput.equals("RI")) {
                fcm1.recoverInfo();

            } else if (userInput.equals("EX")){
                System.out.println("Thank you for using this Formula 1 Championship Manager!");
                System.exit(0);
            }
        } while (true);

    }

}